const express = require("express");
const session = require("express-session");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const UPLOAD_DIR = path.join(DATA_DIR, "uploads");
const NEWS_FILE = path.join(DATA_DIR, "news.json");
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(NEWS_FILE)) fs.writeFileSync(NEWS_FILE, "[]");

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-session-secret-before-deploy",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));
app.use("/uploads", express.static(UPLOAD_DIR));
app.use(express.static(path.join(__dirname, "public")));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().slice(0, 10);
    cb(null, crypto.randomBytes(12).toString("hex") + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = /^(image\/(jpeg|png|gif|webp)|video\/(mp4|webm|quicktime))$/.test(file.mimetype);
    cb(ok ? null : new Error("Nur Bilder oder Videos (JPG, PNG, GIF, WEBP, MP4, WEBM, MOV) sind erlaubt."), ok);
  }
});

function readNews() {
  try { return JSON.parse(fs.readFileSync(NEWS_FILE, "utf8")); } catch { return []; }
}
function writeNews(items) { fs.writeFileSync(NEWS_FILE, JSON.stringify(items, null, 2)); }
function pruneExpired() {
  const now = Date.now();
  const items = readNews();
  const fresh = items.filter(n => now - n.createdAt < 72 * 60 * 60 * 1000);
  const removed = items.filter(n => now - n.createdAt >= 72 * 60 * 60 * 1000);
  removed.forEach(n => { if (n.media) { const p = path.join(UPLOAD_DIR, path.basename(n.media)); if (fs.existsSync(p)) fs.unlinkSync(p); } });
  if (fresh.length !== items.length) writeNews(fresh);
  return fresh;
}
function adminOnly(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  res.status(401).json({ error: "Bitte zuerst als Admin anmelden." });
}

app.get("/api/news", (_req, res) => {
  const items = pruneExpired().sort((a,b) => b.createdAt - a.createdAt);
  res.json(items);
});
app.get("/api/session", (req, res) => res.json({ loggedIn: !!(req.session && req.session.isAdmin) }));
app.post("/api/login", (req, res) => {
  const configured = process.env.ADMIN_PASSWORD || "NoRo-Admin";
  if (!req.body || req.body.password !== configured) return res.status(401).json({ error: "Passwort falsch." });
  req.session.isAdmin = true;
  res.json({ ok: true });
});
app.post("/api/logout", adminOnly, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});
app.post("/api/news", adminOnly, upload.single("media"), (req, res) => {
  const { title, body, village, category } = req.body;
  if (!title || !body || !village || !category) return res.status(400).json({ error: "Bitte alle Pflichtfelder ausfüllen." });
  const item = {
    id: crypto.randomUUID(),
    title: String(title).slice(0, 120),
    body: String(body).slice(0, 5000),
    village: String(village).slice(0, 80),
    category: String(category).slice(0, 50),
    media: req.file ? "/uploads/" + req.file.filename : null,
    mediaType: req.file ? req.file.mimetype : null,
    createdAt: Date.now()
  };
  const items = pruneExpired();
  items.push(item);
  writeNews(items);
  res.json({ ok: true, item });
});
app.delete("/api/news/:id", adminOnly, (req, res) => {
  const items = readNews();
  const item = items.find(n => n.id === req.params.id);
  if (item && item.media) {
    const p = path.join(UPLOAD_DIR, path.basename(item.media));
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }
  writeNews(items.filter(n => n.id !== req.params.id));
  res.json({ ok: true });
});
app.use((err, _req, res, _next) => res.status(400).json({ error: err.message || "Upload fehlgeschlagen." }));

app.listen(PORT, () => console.log(`News Of Roßtal läuft auf Port ${PORT}`));
