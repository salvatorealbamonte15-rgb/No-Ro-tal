const $ = s => document.querySelector(s);
const villageSelect = $("#village");
const villageList = ["Roßtal","Buchschwabach","Buttendorf","Clarsbach","Defersdorf","Großweismannsdorf","Kleinweismannsdorf","Oedenreuth","Raitersaich","Stöckach","Weitersdorf"];
villageList.forEach(v => { villageSelect.add(new Option(v,v)); $("#villages").append(new Option(v,v)); });
let allNews = [];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function ago(ts){const h=Math.max(0,Math.floor((Date.now()-ts)/3600000));return h<1?"Gerade eben":`Vor ${h} Std.`;}
function render(){
  const v = villageSelect.value, c = $("#category").value;
  const items = allNews.filter(n=>(!v||n.village===v)&&(!c||n.category===c));
  $("#count").textContent = `${items.length} ${items.length===1?"Beitrag":"Beiträge"}`;
  $("#news").innerHTML = items.length ? items.map(n=>`<article class="news">
    ${n.media ? (n.mediaType&&n.mediaType.startsWith("video/")?`<video controls playsinline src="${esc(n.media)}"></video>`:`<img src="${esc(n.media)}" alt="">`):""}
    <div class="news-content"><div class="meta"><span class="tag">${esc(n.category)}</span><span>${esc(n.village)}</span><span>· ${ago(n.createdAt)}</span></div>
    <h3>${esc(n.title)}</h3><p>${esc(n.body)}</p></div></article>`).join("") : `<div class="empty">Noch keine News für diese Auswahl<br><small>Schau später nochmal vorbei</small></div>`;
}
async function load(){try{allNews=await (await fetch("/api/news")).json();render();}catch{$("#news").innerHTML='<div class="empty">News konnten nicht geladen werden</div>';}}
villageSelect.addEventListener("change",render); $("#category").addEventListener("change",render);
$("#adminOpen").onclick=async()=>{const s=await fetch("/api/session").then(r=>r.json());if(s.loggedIn)openAdmin();else $("#loginModal").classList.remove("hidden");};
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>$("#"+b.dataset.close).classList.add("hidden"));
$("#loginForm").onsubmit=async e=>{e.preventDefault();const r=await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:$("#password").value})});const d=await r.json();if(!r.ok){$("#loginError").textContent=d.error;return;}$("#loginModal").classList.add("hidden");$("#password").value="";openAdmin();};
async function openAdmin(){$("#adminModal").classList.remove("hidden");await load();renderAdmin();}
function renderAdmin(){$("#adminNews").innerHTML=allNews.length?allNews.map(n=>`<div class="admin-row"><span>${esc(n.title)} <small class="muted">(${esc(n.village)})</small></span><button class="delete" data-id="${esc(n.id)}">Löschen</button></div>`).join(""):"<p class='muted'>Noch keine veröffentlichten News</p>";document.querySelectorAll(".delete").forEach(b=>b.onclick=async()=>{if(!confirm("Diese News wirklich löschen?"))return;await fetch("/api/news/"+encodeURIComponent(b.dataset.id),{method:"DELETE"});await load();renderAdmin();});}
$("#newsForm").onsubmit=async e=>{e.preventDefault();const r=await fetch("/api/news",{method:"POST",body:new FormData(e.target)});const d=await r.json();$("#formMessage").textContent=r.ok?"Veröffentlicht!":d.error;if(r.ok){e.target.reset();await load();renderAdmin();}};
$("#logout").onclick=async()=>{await fetch("/api/logout",{method:"POST"});$("#adminModal").classList.add("hidden");};
load();setInterval(load,60000);
